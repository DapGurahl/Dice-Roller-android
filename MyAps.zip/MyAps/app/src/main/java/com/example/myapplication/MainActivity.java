package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

import java.util.Random;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }

    int nd = 1;
    int rolagem[];
    int hit = 0;

    public void LimpaDados (View view){

         nd = 1;
         hit = 0;
        TextView texto = findViewById(R.id.texto01);
        texto.setText("Número de dados: " + nd);
        texto = findViewById(R.id.texto02);
        texto.setText("Resultado da rolagem: ");
        texto = findViewById(R.id.texto03);
        texto.setText("total de acertos: " + hit);
    }

    public void MaisDados (View view) {
        if (nd < 5) {
            nd += 1;

        }
        TextView texto = findViewById(R.id.texto01);
        texto.setText("Número de dados: " + nd);
    }

    public void MenosDados (View view){
            if (nd > 1) {
                nd = nd - 1;
            }
        TextView texto = findViewById(R.id.texto01);
        texto.setText("Número de dados: " + nd);
        }

    public void RolarDados (View view) {

        if (nd == 1) {
            hit = 0;
            int num = new Random().nextInt(10);
            num++;
            if (num > 7) {
                hit += 1;
            }
            TextView texto = findViewById(R.id.texto02);
            texto.setText("Resultado da rolagem: " + num);
            texto = findViewById(R.id.texto03);
            texto.setText("total de acertos: " + hit);
        }

        if (nd == 2) {
            hit = 0;
            int num = new Random().nextInt(10);
            num++;
            if (num > 7) {
                hit += 1;
            }
            int num2 = new Random().nextInt(10);
            num2++;
            if (num2 > 7) {
                hit += 1;
            }
            TextView texto = findViewById(R.id.texto02);
            texto.setText("Resultado da rolagem: " + num + " , " + num2);
            texto = findViewById(R.id.texto03);
            texto.setText("total de acertos: " + hit);
        }
        if (nd == 3) {
            hit = 0;
            int num = new Random().nextInt(10);
            num++;
            if (num > 7) {
                hit += 1;
            }
            int num2 = new Random().nextInt(10);
            num2++;
            if (num2 > 7) {
                hit += 1;
            }
            int num3 = new Random().nextInt(10);
            num3++;
            if (num3 > 7) {
                hit += 1;
            }
            TextView texto = findViewById(R.id.texto02);
            texto.setText("Resultado da rolagem: " + num + " , " + num2 + " , " + num3);
            texto = findViewById(R.id.texto03);
            texto.setText("total de acertos: " + hit);

        }
        if (nd == 4) {
            hit = 0;
            int num = new Random().nextInt(10);
            num++;
            if (num > 7) {
                hit += 1;
            }
            int num2 = new Random().nextInt(10);
            num2++;
            if (num2 > 7) {
                hit += 1;
            }
            int num3 = new Random().nextInt(10);
            num3++;
            if (num3 > 7) {
                hit += 1;
            }
            int num4 = new Random().nextInt(10);
            num4++;
            if (num4 > 7) {
                hit += 1;
            }
            TextView texto = findViewById(R.id.texto02);
            texto.setText("Resultado da rolagem: " + num + " , " + num2 + " , " + num3 + " , " + num4);
            texto = findViewById(R.id.texto03);
            texto.setText("total de acertos: " + hit);

        }
        if (nd == 5) {

            hit = 0;

            int num = new Random().nextInt(10);
            num++;
            if (num > 7) {
                hit += 1;
            }
            int num2 = new Random().nextInt(10);
            num2++;
            if (num2 > 7) {
                hit += 1;
            }
            int num3 = new Random().nextInt(10);
            num3++;
            if (num3 > 7) {
                hit += 1;
            }
            int num4 = new Random().nextInt(10);
            num4++;
            if (num4 > 7) {
                hit += 1;
            }
            int num5 = new Random().nextInt(10);
            num5++;
            if (num5 > 7) {
                hit += 1;
            }
            TextView texto = findViewById(R.id.texto02);
            texto.setText("Resultado da rolagem: " + num + " , " + num2 + " , " + num3 + " , " + num4 + " , " + num5);
            texto = findViewById(R.id.texto03);
            texto.setText("total de acertos: " + hit);

        }
    }
}